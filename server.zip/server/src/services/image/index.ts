/**
 * 图像生成服务
 */
import { generateImageWithCoze } from './coze'

// 导出所有图像生成方法
export default {
  generateImageWithCoze
} 